/**
 * Script principal do jogo - Inicializa e conecta todos os componentes
 */
document.addEventListener('DOMContentLoaded', function() {
    // Referências globais
    window.players = {};
    window.gameEngine = null;
    window.player = null;
    window.world = null;
    window.gameUI = null;
    window.socket = null;
    
    // Inicializar o jogo
    initGame();
    
    function initGame() {
        // Mostrar tela de carregamento
        const ui = new UI();
        window.gameUI = ui;
        ui.showLoadingScreen(10);
        
        // Verificar se o usuário tem um nome
        const username = sessionStorage.getItem('username');
        if (!username) {
            window.location.href = '/';
            return;
        }
        
        // Inicializar o motor do jogo
        const gameEngine = new GameEngine('gameCanvas');
        window.gameEngine = gameEngine;
        
        // Inicializar o mundo
        const world = new World();
        window.world = world;
        
        // Conectar ao servidor via Socket.IO
        connectToServer(username, gameEngine, world, ui);
    }
    
    function connectToServer(username, gameEngine, world, ui) {
        ui.showLoadingScreen(30);
        ui.addSystemMessage('Conectando ao servidor...');
        
        // Conectar ao servidor
        const socket = io();
        window.socket = socket;
        
        // Evento de conexão estabelecida
        socket.on('connect', function() {
            ui.showLoadingScreen(50);
            ui.addSystemMessage('Conexão estabelecida!');
            
            // Entrar no jogo
            socket.emit('player_join', {
                username: username,
                x: Math.random() * 500 + 750, // Posição inicial aleatória
                y: Math.random() * 500 + 750
            }, function(data) {
                // Callback após entrar no jogo
                if (data && data.player_id) {
                    initializePlayer(data.player_id, username, socket, gameEngine, world, ui);
                }
            });
        });
        
        // Evento de desconexão
        socket.on('disconnect', function() {
            ui.addSystemMessage('Desconectado do servidor. Tentando reconectar...');
        });
        
        // Evento de erro de conexão
        socket.on('connect_error', function() {
            ui.addSystemMessage('Erro ao conectar ao servidor. Tentando novamente...');
        });
        
        // Configurar eventos do socket
        setupSocketEvents(socket, world, ui);
    }
    
    function initializePlayer(playerId, username, socket, gameEngine, world, ui) {
        ui.showLoadingScreen(70);
        
        // Criar o jogador principal
        const player = new Player(playerId, username, 800, 800, true);
        window.player = player;
        players[playerId] = player;
        
        // Inicializar o motor do jogo com o jogador
        gameEngine.init(player, world, ui);
        
        ui.showLoadingScreen(90);
        
        // Adicionar mensagem de boas-vindas
        ui.addSystemMessage(`Bem-vindo ao jogo, ${username}!`);
        ui.addSystemMessage('Use WASD para se mover, I para abrir o inventário e T para chat.');
        
        // Esconder tela de carregamento
        setTimeout(() => {
            ui.hideLoadingScreen();
        }, 500);
    }
    
    function setupSocketEvents(socket, world, ui) {
        // Evento de jogador conectado
        socket.on('player_joined', function(data) {
            if (data.id !== window.player?.id) {
                // Criar novo jogador
                const newPlayer = new Player(data.id, data.username, data.x, data.y, false);
                players[data.id] = newPlayer;
                
                // Adicionar ao motor do jogo
                if (window.gameEngine) {
                    window.gameEngine.addEntity(newPlayer);
                }
                
                // Notificar na interface
                ui.addSystemMessage(`${data.username} entrou no jogo.`);
            }
        });
        
        // Evento de jogador desconectado
        socket.on('player_disconnected', function(data) {
            if (players[data.player_id]) {
                const username = players[data.player_id].username;
                
                // Remover do motor do jogo
                if (window.gameEngine) {
                    window.gameEngine.removeEntity(players[data.player_id]);
                }
                
                // Remover da lista de jogadores
                delete players[data.player_id];
                
                // Notificar na interface
                ui.addSystemMessage(`${username} saiu do jogo.`);
            }
        });
        
        // Evento de movimento de jogador
        socket.on('player_moved', function(data) {
            if (data.player_id !== window.player?.id && players[data.player_id]) {
                players[data.player_id].setPosition(data.x, data.y);
            }
        });
        
        // Evento de atualização de jogador
        socket.on('player_updated', function(data) {
            if (data.id !== window.player?.id && players[data.id]) {
                players[data.id].updateStats(data.health, data.hunger, data.thirst);
            }
        });
        
        // Evento de receber todos os jogadores
        socket.on('all_players', function(playersList) {
            for (const playerData of playersList) {
                if (playerData.id !== window.player?.id) {
                    // Criar jogador se não existir
                    if (!players[playerData.id]) {
                        const newPlayer = new Player(
                            playerData.id,
                            playerData.username,
                            playerData.x,
                            playerData.y,
                            false
                        );
                        
                        newPlayer.updateStats(
                            playerData.health,
                            playerData.hunger,
                            playerData.thirst
                        );
                        
                        players[playerData.id] = newPlayer;
                        
                        // Adicionar ao motor do jogo
                        if (window.gameEngine) {
                            window.gameEngine.addEntity(newPlayer);
                        }
                    } else {
                        // Atualizar jogador existente
                        players[playerData.id].setPosition(playerData.x, playerData.y);
                        players[playerData.id].updateStats(
                            playerData.health,
                            playerData.hunger,
                            playerData.thirst
                        );
                    }
                }
            }
        });
        
        // Evento de receber todos os itens
        socket.on('all_items', function(itemsList) {
            for (const itemData of itemsList) {
                world.addItem(itemData);
            }
        });
        
        // Evento de item coletado
        socket.on('item_collected', function(data) {
            // Remover item do mundo
            world.removeItem(data.item_id);
            
            // Se foi o jogador atual que coletou
            if (data.player_id === window.player?.id) {
                ui.addSystemMessage('Você coletou um item.');
                ui.updateInventory();
            } else if (players[data.player_id]) {
                ui.addSystemMessage(`${players[data.player_id].username} coletou um item.`);
            }
        });
        
        // Evento de item descartado
        socket.on('item_dropped', function(data) {
            // Adicionar item ao mundo
            world.addItem(data.item);
            
            // Se foi o jogador atual que descartou
            if (data.player_id === window.player?.id) {
                ui.updateInventory();
            }
        });
        
        // Evento de mensagem de chat
        socket.on('chat_message', function(data) {
            ui.addChatMessage(data.username, data.message, data.timestamp);
        });
    }
    
    // Função para renascer o jogador (chamada após a morte)
    window.respawnPlayer = function() {
        if (window.socket && window.player) {
            // Gerar nova posição aleatória
            const x = Math.random() * 500 + 750;
            const y = Math.random() * 500 + 750;
            
            // Atualizar posição do jogador
            window.player.x = x;
            window.player.y = y;
            
            // Restaurar status
            window.player.health = 100;
            window.player.hunger = 100;
            window.player.thirst = 100;
            
            // Limpar inventário
            window.player.inventory = [];
            
            // Enviar atualização para o servidor
            window.socket.emit('player_update', {
                player_id: window.player.id,
                x: x,
                y: y,
                health: 100,
                hunger: 100,
                thirst: 100,
                inventory: []
            });
            
            // Notificar na interface
            window.gameUI.addSystemMessage('Você renasceu.');
        }
    };
});
