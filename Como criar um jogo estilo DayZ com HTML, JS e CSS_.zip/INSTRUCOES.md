# Instruções de Uso - Jogo Estilo DayZ Web

## Visão Geral
Este projeto é um jogo multiplayer estilo DayZ desenvolvido com tecnologias web (HTML, CSS e JavaScript) e um backend em Flask. O jogo permite que múltiplos jogadores interajam em um ambiente compartilhado, coletando recursos e sobrevivendo juntos.

## Requisitos do Sistema
- Python 3.11 ou superior
- Navegador web moderno (Chrome, Firefox, Edge, Safari)
- Conexão com a internet para funcionalidades multiplayer

## Instalação e Configuração

### 1. Configuração do Ambiente
```bash
# Navegar até o diretório do projeto
cd jogo-dayz-web

# Ativar o ambiente virtual
source venv/bin/activate  # No Linux/Mac
# ou
venv\Scripts\activate     # No Windows

# Verificar se todas as dependências estão instaladas
pip install -r requirements.txt
```

### 2. Iniciar o Servidor
```bash
# Navegar até o diretório do projeto
cd jogo-dayz-web

# Ativar o ambiente virtual (se ainda não estiver ativado)
source venv/bin/activate  # No Linux/Mac
# ou
venv\Scripts\activate     # No Windows

# Iniciar o servidor Flask
python src/main.py
```

O servidor será iniciado em `http://localhost:5000`.

## Como Jogar

### Acessando o Jogo
1. Abra seu navegador e acesse `http://localhost:5000`
2. Digite seu nome de usuário na tela inicial
3. Clique em "Jogar Agora" para entrar no jogo

### Controles
- **Movimento**: Use as teclas WASD ou as setas do teclado
- **Inventário**: Pressione I para abrir/fechar o inventário
- **Chat**: Pressione T para abrir o chat e digite sua mensagem
- **Interação**: Aproxime-se de itens para coletá-los

### Mecânicas do Jogo
- **Saúde**: Diminui quando você está com fome ou sede
- **Fome e Sede**: Diminuem gradualmente com o tempo
- **Itens**: Colete itens pelo mapa para sobreviver
- **Multiplayer**: Interaja com outros jogadores através do chat

## Estrutura do Projeto

### Backend (Flask)
- `src/main.py`: Ponto de entrada do servidor Flask e lógica do backend
- `src/models/`: Modelos de dados (não implementados no MVP)
- `src/routes/`: Rotas da API (não implementados no MVP)

### Frontend
- `src/templates/`: Arquivos HTML
  - `index.html`: Página inicial
  - `game.html`: Interface principal do jogo
- `src/static/css/`: Estilos CSS
  - `style.css`: Estilos gerais
  - `game.css`: Estilos específicos do jogo
- `src/static/js/`: Scripts JavaScript
  - `index.js`: Script da página inicial
  - `game-engine.js`: Motor do jogo
  - `player.js`: Lógica do jogador
  - `world.js`: Gerenciamento do mundo do jogo
  - `ui.js`: Interface do usuário
  - `game.js`: Script principal do jogo

## Funcionalidades Implementadas (MVP)
- Sistema de login básico
- Renderização do mundo e jogadores
- Movimentação do personagem
- Chat em tempo real entre jogadores
- Sistema de inventário básico
- Coleta e descarte de itens
- Mecânicas de sobrevivência (saúde, fome, sede)
- Sincronização multiplayer em tempo real

## Próximos Passos (Futuras Implementações)
- Sistema de combate
- Inimigos controlados por IA
- Crafting de itens
- Sistema de construção
- Clima e ciclo dia/noite
- Persistência de dados (salvar progresso)
- Mapa maior e mais detalhado
- Sistema de clãs/grupos

## Solução de Problemas
- **Erro de conexão**: Verifique se o servidor está rodando e acessível
- **Problemas de desempenho**: Reduza o número de jogadores ou simplifique o mundo
- **Erros no console**: Verifique o console do navegador (F12) para mensagens de erro

## Contato e Suporte
Para suporte ou dúvidas, entre em contato através do chat do jogo ou reporte problemas diretamente ao desenvolvedor.
