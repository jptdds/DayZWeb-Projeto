// Arquivo principal para a página inicial
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    
    // Manipulador de evento para o formulário de login
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value.trim();
        
        if (username) {
            // Armazenar o nome de usuário na sessão
            sessionStorage.setItem('username', username);
            
            // Redirecionar para a página do jogo
            window.location.href = '/game';
        } else {
            alert('Por favor, insira um nome de usuário válido.');
        }
    });
});
