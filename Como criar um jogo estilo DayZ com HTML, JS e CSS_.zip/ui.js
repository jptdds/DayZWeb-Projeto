/**
 * Classe UI - Gerencia a interface do usuário do jogo
 */
class UI {
    constructor() {
        // Elementos da interface
        this.healthBar = document.getElementById('healthBar');
        this.healthValue = document.getElementById('healthValue');
        this.hungerBar = document.getElementById('hungerBar');
        this.hungerValue = document.getElementById('hungerValue');
        this.thirstBar = document.getElementById('thirstBar');
        this.thirstValue = document.getElementById('thirstValue');
        this.inventoryPanel = document.getElementById('inventoryPanel');
        this.inventorySlots = document.getElementById('inventorySlots');
        this.chatContainer = document.getElementById('chatContainer');
        this.chatMessages = document.getElementById('chatMessages');
        this.chatInput = document.getElementById('chatInput');
        this.sendChatBtn = document.getElementById('sendChat');
        this.minimizeChatBtn = document.getElementById('minimizeChat');
        this.closeInventoryBtn = document.getElementById('closeInventory');
        this.playersCount = document.getElementById('playersCount');
        this.systemMessages = document.getElementById('systemMessages');
        this.loadingScreen = document.getElementById('loadingScreen');
        this.loadingProgress = document.getElementById('loadingProgress');
        this.deathScreen = document.getElementById('deathScreen');
        this.respawnBtn = document.getElementById('respawnBtn');
        
        // Estado da UI
        this.inventoryOpen = false;
        this.chatMinimized = false;
        
        // Configurar eventos da UI
        this.setupEventListeners();
    }
    
    setupEventListeners() {
        // Botão de enviar mensagem
        this.sendChatBtn.addEventListener('click', () => {
            this.sendChatMessage();
        });
        
        // Enviar mensagem ao pressionar Enter
        this.chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendChatMessage();
            }
        });
        
        // Minimizar/maximizar chat
        this.minimizeChatBtn.addEventListener('click', () => {
            this.toggleChat();
        });
        
        // Fechar inventário
        this.closeInventoryBtn.addEventListener('click', () => {
            this.toggleInventory();
        });
        
        // Botão de renascer
        this.respawnBtn.addEventListener('click', () => {
            this.hideDeathScreen();
            window.respawnPlayer();
        });
    }
    
    update() {
        // Atualizar a interface com base no estado do jogador
        if (window.player) {
            this.updateStatusBars(
                window.player.health,
                window.player.hunger,
                window.player.thirst
            );
        }
        
        // Atualizar contador de jogadores
        if (window.players) {
            this.playersCount.textContent = Object.keys(window.players).length;
        }
    }
    
    updateStatusBars(health, hunger, thirst) {
        // Atualizar barras de status
        this.healthBar.style.width = `${health}%`;
        this.healthValue.textContent = Math.round(health);
        
        this.hungerBar.style.width = `${hunger}%`;
        this.hungerValue.textContent = Math.round(hunger);
        
        this.thirstBar.style.width = `${thirst}%`;
        this.thirstValue.textContent = Math.round(thirst);
        
        // Mudar cor das barras com base no valor
        if (health < 25) {
            this.healthBar.style.backgroundColor = '#ff0000';
        } else if (health < 50) {
            this.healthBar.style.backgroundColor = '#ff7700';
        } else {
            this.healthBar.style.backgroundColor = '#ff4d4d';
        }
        
        if (hunger < 25) {
            this.hungerBar.style.backgroundColor = '#ff0000';
        } else {
            this.hungerBar.style.backgroundColor = '#ffa64d';
        }
        
        if (thirst < 25) {
            this.thirstBar.style.backgroundColor = '#ff0000';
        } else {
            this.thirstBar.style.backgroundColor = '#4da6ff';
        }
    }
    
    toggleInventory() {
        this.inventoryOpen = !this.inventoryOpen;
        this.inventoryPanel.style.display = this.inventoryOpen ? 'block' : 'none';
        
        if (this.inventoryOpen) {
            this.updateInventory();
        }
    }
    
    updateInventory() {
        // Limpar slots existentes
        this.inventorySlots.innerHTML = '';
        
        if (!window.player || !window.player.inventory) {
            return;
        }
        
        // Adicionar itens do inventário
        for (const item of window.player.inventory) {
            const slot = document.createElement('div');
            slot.className = 'inventory-slot';
            slot.dataset.itemId = item.id;
            
            const itemName = document.createElement('div');
            itemName.className = 'item-name';
            itemName.textContent = item.name;
            
            slot.appendChild(itemName);
            
            // Adicionar evento de clique para usar/descartar item
            slot.addEventListener('click', () => {
                this.showItemOptions(item);
            });
            
            this.inventorySlots.appendChild(slot);
        }
        
        // Se o inventário estiver vazio, mostrar mensagem
        if (window.player.inventory.length === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.textContent = 'Inventário vazio';
            emptyMessage.style.padding = '20px';
            emptyMessage.style.textAlign = 'center';
            emptyMessage.style.color = '#999';
            this.inventorySlots.appendChild(emptyMessage);
        }
    }
    
    showItemOptions(item) {
        // Criar menu de opções para o item
        const optionsMenu = document.createElement('div');
        optionsMenu.className = 'item-options';
        optionsMenu.style.position = 'absolute';
        optionsMenu.style.backgroundColor = 'rgba(30, 30, 30, 0.9)';
        optionsMenu.style.padding = '10px';
        optionsMenu.style.borderRadius = '4px';
        optionsMenu.style.zIndex = '100';
        
        // Opção de usar item
        const useOption = document.createElement('div');
        useOption.textContent = 'Usar';
        useOption.style.padding = '5px 10px';
        useOption.style.cursor = 'pointer';
        useOption.addEventListener('click', () => {
            this.useItem(item);
            document.body.removeChild(optionsMenu);
        });
        useOption.addEventListener('mouseover', () => {
            useOption.style.backgroundColor = '#444';
        });
        useOption.addEventListener('mouseout', () => {
            useOption.style.backgroundColor = 'transparent';
        });
        
        // Opção de descartar item
        const dropOption = document.createElement('div');
        dropOption.textContent = 'Descartar';
        dropOption.style.padding = '5px 10px';
        dropOption.style.cursor = 'pointer';
        dropOption.addEventListener('click', () => {
            this.dropItem(item);
            document.body.removeChild(optionsMenu);
        });
        dropOption.addEventListener('mouseover', () => {
            dropOption.style.backgroundColor = '#444';
        });
        dropOption.addEventListener('mouseout', () => {
            dropOption.style.backgroundColor = 'transparent';
        });
        
        // Adicionar opções ao menu
        optionsMenu.appendChild(useOption);
        optionsMenu.appendChild(dropOption);
        
        // Posicionar menu próximo ao cursor
        const rect = event.target.getBoundingClientRect();
        optionsMenu.style.left = `${rect.right + 5}px`;
        optionsMenu.style.top = `${rect.top}px`;
        
        // Adicionar menu ao corpo do documento
        document.body.appendChild(optionsMenu);
        
        // Remover menu ao clicar fora dele
        const handleClickOutside = (e) => {
            if (!optionsMenu.contains(e.target) && e.target !== event.target) {
                document.body.removeChild(optionsMenu);
                document.removeEventListener('click', handleClickOutside);
            }
        };
        
        // Adicionar evento com pequeno atraso para evitar que o clique atual o acione
        setTimeout(() => {
            document.addEventListener('click', handleClickOutside);
        }, 10);
    }
    
    useItem(item) {
        // Lógica para usar o item
        if (window.socket && window.player) {
            // Efeitos diferentes com base no tipo de item
            if (item.type === 'food') {
                window.player.hunger = Math.min(100, window.player.hunger + 30);
                this.addSystemMessage(`Você comeu ${item.name} (+30 Fome)`);
            } else if (item.type === 'weapon') {
                this.addSystemMessage(`Você equipou ${item.name}`);
            } else {
                this.addSystemMessage(`Você usou ${item.name}`);
            }
            
            // Remover item do inventário
            window.player.removeFromInventory(item.id);
            
            // Atualizar inventário na interface
            this.updateInventory();
            
            // Enviar atualização para o servidor
            window.socket.emit('player_update', {
                player_id: window.player.id,
                health: window.player.health,
                hunger: window.player.hunger,
                thirst: window.player.thirst,
                inventory: window.player.inventory
            });
        }
    }
    
    dropItem(item) {
        // Lógica para descartar o item
        if (window.socket && window.player) {
            window.socket.emit('item_drop', {
                player_id: window.player.id,
                item: item
            });
            
            // Remover item do inventário
            window.player.removeFromInventory(item.id);
            
            // Atualizar inventário na interface
            this.updateInventory();
            
            this.addSystemMessage(`Você descartou ${item.name}`);
        }
    }
    
    toggleChat() {
        this.chatMinimized = !this.chatMinimized;
        
        if (this.chatMinimized) {
            this.chatMessages.style.display = 'none';
            this.chatInput.style.display = 'none';
            this.sendChatBtn.style.display = 'none';
            this.chatContainer.style.height = '30px';
            this.minimizeChatBtn.textContent = '+';
        } else {
            this.chatMessages.style.display = 'block';
            this.chatInput.style.display = 'block';
            this.sendChatBtn.style.display = 'block';
            this.chatContainer.style.height = 'auto';
            this.minimizeChatBtn.textContent = '_';
        }
    }
    
    focusChat() {
        // Garantir que o chat esteja visível
        if (this.chatMinimized) {
            this.toggleChat();
        }
        
        // Focar no campo de entrada
        this.chatInput.focus();
    }
    
    sendChatMessage() {
        const message = this.chatInput.value.trim();
        
        if (message && window.socket && window.player) {
            window.socket.emit('chat_message', {
                player_id: window.player.id,
                message: message
            });
            
            this.chatInput.value = '';
        }
    }
    
    addChatMessage(username, message, timestamp) {
        const messageElement = document.createElement('div');
        messageElement.className = 'chat-message';
        
        const usernameSpan = document.createElement('span');
        usernameSpan.className = 'username';
        usernameSpan.textContent = username;
        
        const timestampSpan = document.createElement('span');
        timestampSpan.className = 'timestamp';
        timestampSpan.textContent = this.formatTimestamp(timestamp);
        
        const messageText = document.createElement('div');
        messageText.textContent = message;
        
        messageElement.appendChild(usernameSpan);
        messageElement.appendChild(timestampSpan);
        messageElement.appendChild(messageText);
        
        this.chatMessages.appendChild(messageElement);
        
        // Rolar para a mensagem mais recente
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        
        // Garantir que o chat esteja visível se receber uma nova mensagem
        if (this.chatMinimized) {
            this.toggleChat();
        }
    }
    
    formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        return ` [${hours}:${minutes}]`;
    }
    
    addSystemMessage(message) {
        // Adicionar mensagem ao chat
        this.addChatMessage('Sistema', message, new Date().toISOString());
        
        // Mostrar mensagem flutuante
        const messageElement = document.createElement('div');
        messageElement.className = 'system-message';
        messageElement.textContent = message;
        
        this.systemMessages.appendChild(messageElement);
        
        // Remover mensagem após a animação
        setTimeout(() => {
            this.systemMessages.removeChild(messageElement);
        }, 5000);
    }
    
    showLoadingScreen(progress = 0) {
        this.loadingScreen.style.display = 'flex';
        this.loadingProgress.style.width = `${progress}%`;
    }
    
    hideLoadingScreen() {
        this.loadingScreen.style.display = 'none';
    }
    
    showDeathScreen() {
        this.deathScreen.style.display = 'flex';
    }
    
    hideDeathScreen() {
        this.deathScreen.style.display = 'none';
    }
}
