/**
 * Classe Player - Representa o jogador e outros personagens no jogo
 */
class Player {
    constructor(id, username, x, y, isMainPlayer = false) {
        this.id = id;
        this.username = username;
        this.x = x;
        this.y = y;
        this.targetX = x;
        this.targetY = y;
        this.width = 40;
        this.height = 40;
        this.speed = 200; // pixels por segundo
        this.isMainPlayer = isMainPlayer;
        this.health = 100;
        this.hunger = 100;
        this.thirst = 100;
        this.inventory = [];
        this.color = this.generateColor();
        this.lastUpdate = Date.now();
        
        // Controles de movimento
        this.moveUp = false;
        this.moveDown = false;
        this.moveLeft = false;
        this.moveRight = false;
        
        if (isMainPlayer) {
            this.setupControls();
        }
    }
    
    generateColor() {
        // Gerar uma cor baseada no nome de usuário para diferenciar jogadores
        let hash = 0;
        for (let i = 0; i < this.username.length; i++) {
            hash = this.username.charCodeAt(i) + ((hash << 5) - hash);
        }
        
        const hue = Math.abs(hash % 360);
        return `hsl(${hue}, 70%, 60%)`;
    }
    
    setupControls() {
        // Configurar eventos de teclado para movimento
        document.addEventListener('keydown', (e) => {
            switch (e.key.toLowerCase()) {
                case 'w':
                case 'arrowup':
                    this.moveUp = true;
                    break;
                case 's':
                case 'arrowdown':
                    this.moveDown = true;
                    break;
                case 'a':
                case 'arrowleft':
                    this.moveLeft = true;
                    break;
                case 'd':
                case 'arrowright':
                    this.moveRight = true;
                    break;
                case 'i':
                    // Abrir/fechar inventário
                    window.gameUI.toggleInventory();
                    break;
                case 't':
                    // Abrir/focar chat
                    window.gameUI.focusChat();
                    break;
            }
        });
        
        document.addEventListener('keyup', (e) => {
            switch (e.key.toLowerCase()) {
                case 'w':
                case 'arrowup':
                    this.moveUp = false;
                    break;
                case 's':
                case 'arrowdown':
                    this.moveDown = false;
                    break;
                case 'a':
                case 'arrowleft':
                    this.moveLeft = false;
                    break;
                case 'd':
                case 'arrowright':
                    this.moveRight = false;
                    break;
            }
        });
    }
    
    update(deltaTime) {
        // Converter deltaTime para segundos
        const dt = deltaTime / 1000;
        
        // Atualizar posição com base nos controles (apenas para o jogador principal)
        if (this.isMainPlayer) {
            let moved = false;
            let dx = 0;
            let dy = 0;
            
            if (this.moveUp) {
                dy -= this.speed * dt;
                moved = true;
            }
            if (this.moveDown) {
                dy += this.speed * dt;
                moved = true;
            }
            if (this.moveLeft) {
                dx -= this.speed * dt;
                moved = true;
            }
            if (this.moveRight) {
                dx += this.speed * dt;
                moved = true;
            }
            
            // Normalizar movimento diagonal
            if (dx !== 0 && dy !== 0) {
                const factor = 1 / Math.sqrt(2);
                dx *= factor;
                dy *= factor;
            }
            
            // Atualizar posição
            this.x += dx;
            this.y += dy;
            
            // Limites do mundo (temporário)
            this.x = Math.max(0, Math.min(2000, this.x));
            this.y = Math.max(0, Math.min(2000, this.y));
            
            // Enviar atualização para o servidor se houve movimento
            if (moved && window.socket) {
                window.socket.emit('player_move', {
                    player_id: this.id,
                    x: this.x,
                    y: this.y
                });
            }
            
            // Atualizar status do jogador (fome e sede diminuem com o tempo)
            const now = Date.now();
            if (now - this.lastUpdate > 5000) { // A cada 5 segundos
                this.hunger = Math.max(0, this.hunger - 0.5);
                this.thirst = Math.max(0, this.thirst - 0.7);
                
                // Se fome ou sede chegarem a zero, a saúde começa a diminuir
                if (this.hunger === 0 || this.thirst === 0) {
                    this.health = Math.max(0, this.health - 1);
                }
                
                // Enviar atualização para o servidor
                if (window.socket) {
                    window.socket.emit('player_update', {
                        player_id: this.id,
                        health: this.health,
                        hunger: this.hunger,
                        thirst: this.thirst
                    });
                }
                
                this.lastUpdate = now;
            }
        } else {
            // Para outros jogadores, mover suavemente para a posição alvo
            const lerpFactor = 0.1;
            this.x += (this.targetX - this.x) * lerpFactor;
            this.y += (this.targetY - this.y) * lerpFactor;
        }
    }
    
    render(ctx, mainPlayer) {
        // Calcular posição na tela (relativa ao jogador principal)
        const screenX = this.x - mainPlayer.x + ctx.canvas.width / 2;
        const screenY = this.y - mainPlayer.y + ctx.canvas.height / 2;
        
        // Não renderizar se estiver fora da tela
        if (screenX < -this.width || screenX > ctx.canvas.width + this.width ||
            screenY < -this.height || screenY > ctx.canvas.height + this.height) {
            return;
        }
        
        // Desenhar o jogador (círculo colorido)
        ctx.beginPath();
        ctx.arc(screenX, screenY, this.width / 2, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        ctx.strokeStyle = this.isMainPlayer ? '#fff' : '#000';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Desenhar nome do jogador
        ctx.font = '14px Arial';
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'center';
        ctx.fillText(this.username, screenX, screenY - this.height / 2 - 10);
        
        // Desenhar barra de vida acima do jogador
        const healthBarWidth = this.width;
        const healthBarHeight = 5;
        const healthBarX = screenX - healthBarWidth / 2;
        const healthBarY = screenY - this.height / 2 - 5;
        
        // Fundo da barra
        ctx.fillStyle = '#333';
        ctx.fillRect(healthBarX, healthBarY, healthBarWidth, healthBarHeight);
        
        // Barra de vida
        ctx.fillStyle = '#ff4d4d';
        ctx.fillRect(healthBarX, healthBarY, healthBarWidth * (this.health / 100), healthBarHeight);
    }
    
    setPosition(x, y) {
        if (!this.isMainPlayer) {
            this.targetX = x;
            this.targetY = y;
        }
    }
    
    updateStats(health, hunger, thirst) {
        this.health = health;
        this.hunger = hunger;
        this.thirst = thirst;
    }
    
    addToInventory(item) {
        this.inventory.push(item);
    }
    
    removeFromInventory(itemId) {
        this.inventory = this.inventory.filter(item => item.id !== itemId);
    }
}
