/**
 * Classe World - Gerencia o mundo do jogo, incluindo mapa e itens
 */
class World {
    constructor() {
        this.width = 2000;
        this.height = 2000;
        this.tileSize = 50;
        this.grid = this.generateGrid();
        this.items = new Map();
        this.obstacles = [];
        
        // Gerar alguns obstáculos aleatórios
        this.generateObstacles();
    }
    
    generateGrid() {
        // Gerar uma grade simples para o mundo
        const grid = [];
        const rows = Math.ceil(this.height / this.tileSize);
        const cols = Math.ceil(this.width / this.tileSize);
        
        for (let y = 0; y < rows; y++) {
            const row = [];
            for (let x = 0; x < cols; x++) {
                // 0 = grama, 1 = terra, 2 = água
                let tileType = 0;
                
                // Adicionar algumas variações aleatórias
                const random = Math.random();
                if (random < 0.2) {
                    tileType = 1;
                } else if (random < 0.25) {
                    tileType = 2;
                }
                
                row.push(tileType);
            }
            grid.push(row);
        }
        
        return grid;
    }
    
    generateObstacles() {
        // Gerar árvores e rochas aleatórias
        const numObstacles = 100;
        
        for (let i = 0; i < numObstacles; i++) {
            const x = Math.random() * this.width;
            const y = Math.random() * this.height;
            const type = Math.random() < 0.7 ? 'tree' : 'rock';
            const size = type === 'tree' ? 40 : 30;
            
            this.obstacles.push({
                x,
                y,
                type,
                size
            });
        }
    }
    
    update(deltaTime) {
        // Atualizar estado do mundo se necessário
    }
    
    render(ctx, player) {
        // Calcular quais tiles estão visíveis na tela
        const startX = Math.floor((player.x - ctx.canvas.width / 2) / this.tileSize);
        const startY = Math.floor((player.y - ctx.canvas.height / 2) / this.tileSize);
        const endX = Math.ceil((player.x + ctx.canvas.width / 2) / this.tileSize);
        const endY = Math.ceil((player.y + ctx.canvas.height / 2) / this.tileSize);
        
        // Renderizar os tiles visíveis
        for (let y = Math.max(0, startY); y < Math.min(this.grid.length, endY); y++) {
            for (let x = Math.max(0, startX); x < Math.min(this.grid[0].length, endX); x++) {
                const tileType = this.grid[y][x];
                const screenX = x * this.tileSize - player.x + ctx.canvas.width / 2;
                const screenY = y * this.tileSize - player.y + ctx.canvas.height / 2;
                
                // Definir cor com base no tipo de tile
                switch (tileType) {
                    case 0: // Grama
                        ctx.fillStyle = '#4a8f29';
                        break;
                    case 1: // Terra
                        ctx.fillStyle = '#8b5a2b';
                        break;
                    case 2: // Água
                        ctx.fillStyle = '#4a7bff';
                        break;
                }
                
                ctx.fillRect(screenX, screenY, this.tileSize, this.tileSize);
                
                // Adicionar uma borda sutil para diferenciar os tiles
                ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
                ctx.strokeRect(screenX, screenY, this.tileSize, this.tileSize);
            }
        }
        
        // Renderizar obstáculos
        for (const obstacle of this.obstacles) {
            const screenX = obstacle.x - player.x + ctx.canvas.width / 2;
            const screenY = obstacle.y - player.y + ctx.canvas.height / 2;
            
            // Não renderizar se estiver fora da tela
            if (screenX < -obstacle.size || screenX > ctx.canvas.width + obstacle.size ||
                screenY < -obstacle.size || screenY > ctx.canvas.height + obstacle.size) {
                continue;
            }
            
            if (obstacle.type === 'tree') {
                // Desenhar tronco
                ctx.fillStyle = '#8b4513';
                ctx.fillRect(screenX - 5, screenY - 10, 10, 20);
                
                // Desenhar copa
                ctx.beginPath();
                ctx.arc(screenX, screenY - 25, 20, 0, Math.PI * 2);
                ctx.fillStyle = '#2e8b57';
                ctx.fill();
            } else if (obstacle.type === 'rock') {
                // Desenhar rocha
                ctx.beginPath();
                ctx.arc(screenX, screenY, 15, 0, Math.PI * 2);
                ctx.fillStyle = '#808080';
                ctx.fill();
            }
        }
        
        // Renderizar itens
        for (const item of this.items.values()) {
            const screenX = item.x - player.x + ctx.canvas.width / 2;
            const screenY = item.y - player.y + ctx.canvas.height / 2;
            
            // Não renderizar se estiver fora da tela
            if (screenX < -20 || screenX > ctx.canvas.width + 20 ||
                screenY < -20 || screenY > ctx.canvas.height + 20) {
                continue;
            }
            
            // Desenhar item
            ctx.beginPath();
            ctx.arc(screenX, screenY, 10, 0, Math.PI * 2);
            
            // Cor baseada no tipo de item
            switch (item.type) {
                case 'food':
                    ctx.fillStyle = '#ffa64d';
                    break;
                case 'weapon':
                    ctx.fillStyle = '#ff4d4d';
                    break;
                case 'material':
                    ctx.fillStyle = '#4da6ff';
                    break;
                default:
                    ctx.fillStyle = '#ffffff';
            }
            
            ctx.fill();
            ctx.strokeStyle = '#000';
            ctx.lineWidth = 1;
            ctx.stroke();
            
            // Nome do item
            ctx.font = '12px Arial';
            ctx.fillStyle = '#fff';
            ctx.textAlign = 'center';
            ctx.fillText(item.name, screenX, screenY - 15);
        }
    }
    
    addItem(item) {
        this.items.set(item.id, item);
    }
    
    removeItem(itemId) {
        this.items.delete(itemId);
    }
    
    getItemsInRadius(x, y, radius) {
        const result = [];
        
        for (const item of this.items.values()) {
            const dx = item.x - x;
            const dy = item.y - y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance <= radius) {
                result.push(item);
            }
        }
        
        return result;
    }
    
    isPositionValid(x, y, radius) {
        // Verificar limites do mundo
        if (x - radius < 0 || x + radius > this.width || y - radius < 0 || y + radius > this.height) {
            return false;
        }
        
        // Verificar colisão com obstáculos
        for (const obstacle of this.obstacles) {
            const dx = obstacle.x - x;
            const dy = obstacle.y - y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < radius + obstacle.size / 2) {
                return false;
            }
        }
        
        return true;
    }
}
