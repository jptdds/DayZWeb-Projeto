import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, render_template, request, jsonify, session
from flask_socketio import SocketIO, emit, join_room, leave_room
import json
import uuid
from datetime import datetime

# Inicialização do app Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'dayz-web-secret-key'
# Descomente a linha abaixo se precisar usar MySQL
# app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"

# Inicialização do SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Armazenamento temporário de jogadores (em memória)
players = {}
items = {}

# Rotas da aplicação web
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/game')
def game():
    return render_template('game.html')

# API para obter lista de jogadores
@app.route('/api/players', methods=['GET'])
def get_players():
    return jsonify(list(players.values()))

# API para obter lista de itens
@app.route('/api/items', methods=['GET'])
def get_items():
    return jsonify(list(items.values()))

# Eventos SocketIO para comunicação em tempo real
@socketio.on('connect')
def handle_connect():
    print(f'Cliente conectado: {request.sid}')

@socketio.on('disconnect')
def handle_disconnect():
    print(f'Cliente desconectado: {request.sid}')
    # Remover jogador quando desconectar
    player_id = None
    for pid, player in players.items():
        if player.get('sid') == request.sid:
            player_id = pid
            break
    
    if player_id:
        del players[player_id]
        emit('player_disconnected', {'player_id': player_id}, broadcast=True)

@socketio.on('player_join')
def handle_player_join(data):
    player_id = str(uuid.uuid4())
    player_data = {
        'id': player_id,
        'sid': request.sid,
        'username': data.get('username', f'Player_{player_id[:5]}'),
        'x': data.get('x', 100),
        'y': data.get('y', 100),
        'health': 100,
        'hunger': 100,
        'thirst': 100,
        'inventory': [],
        'lastUpdate': datetime.now().isoformat()
    }
    
    players[player_id] = player_data
    
    # Enviar dados do novo jogador para todos
    emit('player_joined', player_data, broadcast=True)
    
    # Enviar dados de todos os jogadores existentes para o novo jogador
    emit('all_players', list(players.values()), to=request.sid)
    
    # Enviar dados de todos os itens existentes para o novo jogador
    emit('all_items', list(items.values()), to=request.sid)
    
    return {'player_id': player_id}

@socketio.on('player_move')
def handle_player_move(data):
    player_id = data.get('player_id')
    if player_id in players:
        players[player_id]['x'] = data.get('x')
        players[player_id]['y'] = data.get('y')
        players[player_id]['lastUpdate'] = datetime.now().isoformat()
        
        # Transmitir movimento para todos os outros jogadores
        emit('player_moved', {
            'player_id': player_id,
            'x': data.get('x'),
            'y': data.get('y')
        }, broadcast=True)

@socketio.on('player_update')
def handle_player_update(data):
    player_id = data.get('player_id')
    if player_id in players:
        # Atualizar apenas os campos fornecidos
        for key, value in data.items():
            if key != 'player_id' and key in players[player_id]:
                players[player_id][key] = value
        
        players[player_id]['lastUpdate'] = datetime.now().isoformat()
        
        # Transmitir atualização para todos os jogadores
        emit('player_updated', players[player_id], broadcast=True)

@socketio.on('chat_message')
def handle_chat_message(data):
    player_id = data.get('player_id')
    message = data.get('message')
    
    if player_id in players and message:
        chat_data = {
            'player_id': player_id,
            'username': players[player_id]['username'],
            'message': message,
            'timestamp': datetime.now().isoformat()
        }
        
        # Transmitir mensagem para todos os jogadores
        emit('chat_message', chat_data, broadcast=True)

@socketio.on('item_collect')
def handle_item_collect(data):
    player_id = data.get('player_id')
    item_id = data.get('item_id')
    
    if player_id in players and item_id in items:
        # Adicionar item ao inventário do jogador
        players[player_id]['inventory'].append(items[item_id])
        
        # Remover item do mundo
        del items[item_id]
        
        # Notificar todos os jogadores
        emit('item_collected', {
            'player_id': player_id,
            'item_id': item_id
        }, broadcast=True)

@socketio.on('item_drop')
def handle_item_drop(data):
    player_id = data.get('player_id')
    item_data = data.get('item')
    
    if player_id in players and item_data:
        item_id = str(uuid.uuid4())
        
        # Definir posição do item próxima ao jogador
        item_data['id'] = item_id
        item_data['x'] = players[player_id]['x'] + 10  # Pequeno deslocamento
        item_data['y'] = players[player_id]['y'] + 10
        
        # Adicionar item ao mundo
        items[item_id] = item_data
        
        # Remover item do inventário do jogador (lógica simplificada)
        players[player_id]['inventory'] = [
            item for item in players[player_id]['inventory'] 
            if item.get('name') != item_data.get('name')
        ]
        
        # Notificar todos os jogadores
        emit('item_dropped', {
            'player_id': player_id,
            'item': item_data
        }, broadcast=True)

# Iniciar o servidor
if __name__ == '__main__':
    # Criar alguns itens iniciais no mundo
    for i in range(10):
        item_id = str(uuid.uuid4())
        items[item_id] = {
            'id': item_id,
            'name': f'Item_{i}',
            'type': 'food' if i % 3 == 0 else 'weapon' if i % 3 == 1 else 'material',
            'x': 100 + i * 50,
            'y': 100 + i * 30,
            'value': 10 + i * 5
        }
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
