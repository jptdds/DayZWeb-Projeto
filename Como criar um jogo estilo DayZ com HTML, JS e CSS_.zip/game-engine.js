/**
 * Motor do jogo - Responsável pela renderização e loop principal
 */
class GameEngine {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.running = false;
        this.lastTimestamp = 0;
        this.entities = [];
        this.player = null;
        this.world = null;
        this.ui = null;
        
        // Ajustar tamanho do canvas para preencher a tela
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    resizeCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }
    
    init(player, world, ui) {
        this.player = player;
        this.world = world;
        this.ui = ui;
        
        // Adicionar o jogador à lista de entidades
        this.entities.push(player);
        
        // Iniciar o loop do jogo
        this.running = true;
        requestAnimationFrame(this.gameLoop.bind(this));
    }
    
    gameLoop(timestamp) {
        if (!this.running) return;
        
        // Calcular delta time (tempo desde o último frame)
        const deltaTime = timestamp - this.lastTimestamp;
        this.lastTimestamp = timestamp;
        
        // Atualizar
        this.update(deltaTime);
        
        // Renderizar
        this.render();
        
        // Continuar o loop
        requestAnimationFrame(this.gameLoop.bind(this));
    }
    
    update(deltaTime) {
        // Atualizar o mundo
        if (this.world) {
            this.world.update(deltaTime);
        }
        
        // Atualizar todas as entidades
        for (const entity of this.entities) {
            if (entity.update) {
                entity.update(deltaTime);
            }
        }
        
        // Atualizar a UI
        if (this.ui) {
            this.ui.update();
        }
    }
    
    render() {
        // Limpar o canvas
        this.ctx.fillStyle = '#222';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Renderizar o mundo
        if (this.world) {
            this.world.render(this.ctx, this.player);
        }
        
        // Renderizar todas as entidades
        // Ordenar por posição Y para dar sensação de profundidade
        const sortedEntities = [...this.entities].sort((a, b) => a.y - b.y);
        
        for (const entity of sortedEntities) {
            if (entity.render) {
                entity.render(this.ctx, this.player);
            }
        }
    }
    
    addEntity(entity) {
        this.entities.push(entity);
    }
    
    removeEntity(entity) {
        const index = this.entities.indexOf(entity);
        if (index !== -1) {
            this.entities.splice(index, 1);
        }
    }
    
    stop() {
        this.running = false;
    }
}
